import javax.swing.JOptionPane;
import java.util.ArrayList;

public class StoredMessages {
    public static ArrayList<String> messageIDs = new ArrayList<>();
    public static ArrayList<String> messageHashes = new ArrayList<>();
    public static ArrayList<String> recipients = new ArrayList<>();
    public static ArrayList<String> messages = new ArrayList<>();
    public static ArrayList<String> senders = new ArrayList<>();

    public static void addMessage(String id, String hash, String recipient, String message, String sender) {
        messageIDs.add(id);
        messageHashes.add(hash);
        recipients.add(recipient);
        messages.add(message);
        senders.add(sender);
    }

    public static void showStoredMessagesMenu() {
        while (true) {
            String choice = JOptionPane.showInputDialog(
                "--- Stored Messages Menu ---\n" +
                "1. Display all stored messages\n" +
                "2. Display longest message\n" +
                "3. Search by Message ID\n" +
                "4. Search by Recipient\n" +
                "5. Delete by Message Hash\n" +
                "6. Display report\n" +
                "7. Back / Exit"
            );
            if (choice == null || choice.equals("7")) break;

            if (choice.equals("1")) {
                String all = "All Stored Messages:\n\n";
                for (int i = 0; i < messages.size(); i++) {
                    all += "ID: " + messageIDs.get(i) + "\nHash: " + messageHashes.get(i) +
                           "\nRecipient: " + recipients.get(i) + "\nMessage: " + messages.get(i) + "\n\n";
                }
                JOptionPane.showMessageDialog(null, all);
            }
            else if (choice.equals("2")) {
                int longest = 0;
                for (int i = 1; i < messages.size(); i++) {
                    if (messages.get(i).length() > messages.get(longest).length()) longest = i;
                }
                JOptionPane.showMessageDialog(null, "Longest Message:\n" + messages.get(longest) + "\nRecipient: " + recipients.get(longest));
            }
            else if (choice.equals("3")) {
                String id = JOptionPane.showInputDialog("Enter Message ID to search:");
                boolean found = false;
                for (int i = 0; i < messageIDs.size(); i++) {
                    if (messageIDs.get(i).equals(id)) {
                        JOptionPane.showMessageDialog(null, "Found:\nRecipient: " + recipients.get(i) + "\nMessage: " + messages.get(i));
                        found = true;
                    }
                }
                if (!found) JOptionPane.showMessageDialog(null, "No message found with that ID.");
            }
            else if (choice.equals("4")) {
                String rec = JOptionPane.showInputDialog("Enter Recipient to search (e.g. +27838884567):");
                String result = "Messages for " + rec + ":\n\n";
                boolean found = false;
                for (int i = 0; i < recipients.size(); i++) {
                    if (recipients.get(i).equals(rec)) {
                        result += messages.get(i) + "\n";
                        found = true;
                    }
                }
                if (!found) result = "No messages for that recipient.";
                JOptionPane.showMessageDialog(null, result);
            }
            else if (choice.equals("5")) {
                String hash = JOptionPane.showInputDialog("Enter Message Hash to delete:");
                boolean deleted = false;
                for (int i = 0; i < messageHashes.size(); i++) {
                    if (messageHashes.get(i).equals(hash)) {
                        messageIDs.remove(i); messageHashes.remove(i);
                        recipients.remove(i); messages.remove(i); senders.remove(i);
                        JOptionPane.showMessageDialog(null, "Message successfully deleted.");
                        deleted = true;
                        break;
                    }
                }
                if (!deleted) JOptionPane.showMessageDialog(null, "No message found with that hash.");
            }
            else if (choice.equals("6")) {
                String report = "--- Full Report ---\n\n";
                for (int i = 0; i < messages.size(); i++) {
                    report += "Hash: " + messageHashes.get(i) + "\nRecipient: " + recipients.get(i) + "\nMessage: " + messages.get(i) + "\n\n";
                }
                JOptionPane.showMessageDialog(null, report);
            }
        }
    }

    // THIS IS THE PART THAT LETS YOU RUN STORED MESSAGES ALONE
    public static void main(String[] args) {
        addMessage("0:0", "0:0 DID YOU", "+27834557896", "Did you get the cake?", "Me");
        addMessage("0:1", "0:1 WHERE ARE", "+27838884567", "Where are you? You are late! I have asked you to be on time.", "Me");
        addMessage("0:2", "0:2 YOHOOO I", "+27834484567", "Yohooo, I am at your gate.", "Me");
        addMessage("0:3", "0:3 IT IS", "+27838884567", "It is dinner time!", "Me");
        addMessage("0:4", "0:4 OK I", "+27834484567", "Ok, I am leaving home now.", "Me");
        showStoredMessagesMenu();
    }
}